package herdImmunitySim;

import java.util.ArrayList;
import java.util.List;

import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;

public class Recovered {

	private ContinuousSpace<Object> space;
	private Grid<Object> grid;
	private int interacted = 0;
	
	
	public Recovered(ContinuousSpace<Object> space, Grid<Object> grid) {
		this.space = space;
		this.grid = grid;
	}
	
	@ScheduledMethod(start = 1, interval = 1)
	public void step() {
		move();
		interact();
	}
	
	public void move() {
		NdPoint myPoint = space.getLocation(this);
		double angle = RandomHelper.nextDoubleFromTo(0, 6);
		space.moveByVector(this, 1, angle, 0);
		myPoint = space.getLocation(this);
		grid.moveTo(this, (int) myPoint.getX(), (int) myPoint.getY());
			
	}
	
	public void interact() {
		GridPoint pt = grid.getLocation(this);
		List<Object> interactedWith = new ArrayList<Object>();

		for (Object obj : grid.getObjectsAt(pt.getX(), pt.getY())) {
			if (obj instanceof Susceptible || obj instanceof Vaccinated || obj instanceof Infected ) {
				interactedWith.add(obj);
			}
		}

		if (interactedWith.size() > 0) {
			interacted++;
		}
	}
	
	public int interacted() {
		return interacted;
	}
}
