package herdImmunitySim;

import java.util.ArrayList;
import java.util.List;


import repast.simphony.context.Context;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.NdPoint;
import repast.simphony.space.graph.Network;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.util.ContextUtils;

public class Infected {

	private ContinuousSpace<Object> space;
	private Grid<Object> grid;
	private int recoverTimer = 75;
	private int infectedCount = 0;
	public int interacted = 0;
	public int failedToInfect = 0;
	
	public Infected(ContinuousSpace<Object> space, Grid<Object> grid) {
		this.space = space;
		this.grid = grid;
	}
	
	@ScheduledMethod(start = 1, interval = 1)
	public void step() {
		move();
		infect();
		recover();
	}
	
	public void move() {
		NdPoint myPoint = space.getLocation(this);
		double angle = RandomHelper.nextDoubleFromTo(0, 6);
		space.moveByVector(this, 1, angle, 0);
		myPoint = space.getLocation(this);
		grid.moveTo(this, (int) myPoint.getX(), (int) myPoint.getY());
			
	}
	
	public void infect() {
		GridPoint pt = grid.getLocation(this);
		List<Object> susceptibles = new ArrayList<Object>();
		List<Object> interactedWith = new ArrayList<Object>();
		for (Object obj : grid.getObjectsAt(pt.getX(), pt.getY())) {
			if (obj instanceof Susceptible) {
				susceptibles.add(obj);
			}
			if (obj instanceof Susceptible || obj instanceof Vaccinated || obj instanceof Recovered) {
				interactedWith.add(obj);
			}
		}

		if (susceptibles.size() > 0 ) {
			if(RandomHelper.nextIntFromTo(1, 100) <= 100) {
				int index = RandomHelper.nextIntFromTo(0, susceptibles.size() - 1);
				Object obj = susceptibles.get(index);
				NdPoint spacePt = space.getLocation(obj);
				Context<Object> context = ContextUtils.getContext(obj);
				context.remove(obj);
				Infected infected = new Infected(space, grid);
				context.add(infected);
				space.moveTo(infected, spacePt.getX(), spacePt.getY());
				grid.moveTo(infected, pt.getX(), pt.getY());
			
				infectedCount++;
			}
			failedToInfect++;
		}
		if (interactedWith.size() > 0) {
			interacted++;
		}
		
	}
	
	public void recover() {
		recoverTimer--;
		if(recoverTimer<=0) {
			GridPoint pt = grid.getLocation(this);
			NdPoint spacePt = space.getLocation(this); 
			Context<Object> context = ContextUtils.getContext(this);
			context.remove(this);
			Recovered recovered = new Recovered(space, grid);
			context.add(recovered);
			space.moveTo(recovered, spacePt.getX(), spacePt.getY());
			grid.moveTo(recovered, pt.getX(), pt.getY());
		}
	}
	
	
	public int infected() {
		return infectedCount;
	}
	
	public int interacted()
	{
		return interacted;
	}
	
	public int failedToInfect() {
		return failedToInfect;
	}
}
