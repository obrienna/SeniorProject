Place your model data files in this directory.  Files placed here will be 
automatically included in batch runs and stand-alone model jars.